package controllers;

import models.Paper;
import models.Search;
import models.SearchImplementation;

import play.mvc.*;

import views.html.*;

import javax.inject.Inject;
import javax.xml.transform.Result;

public class PapersController extends Controller{

    public Result details() {
        System.out.println("Search Results...");
        JSonNode request = request().body().asJson();
        String tag_request = request.get("tag").asText(); //get tag request
        String title_request = request.get("title").asText(); //get title request
        String author_request = request.get("author").asText(); //get author request

        try{
            Search search = new SearchImplementation();
            Paper results = search.findByTitle(title_request);



        }
    }


}
