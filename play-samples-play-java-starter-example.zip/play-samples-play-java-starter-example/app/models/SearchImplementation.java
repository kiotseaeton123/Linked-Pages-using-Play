package models;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedMap;
import java.util.concurrent.ConcurrentSkipListMap;

public class SearchImplementation implements Search {

    SortedMap<Long, Paper> papers = new ConcurrentSkipListMap<>(); //to list all papers
    SortedMap<Long, Paper> papers_by_title = new ConcurrentSkipListMap<>(); //key = title, values: papers
    SortedMap<Long, Paper> papers_by_author = new ConcurrentSkipListMap<>(); //key = author, values: papers
    SortedMap<Long, Paper> papers_by_tag = new ConcurrentSkipListMap<>(); //key = tag(or List of tags), values: papers

    @Override
    public List<Paper> list() {
        return new ArrayList<Paper>(papers.values());
    }

    @Override
    public Paper findByTitle(String title) {
        return papers_by_title.get(title);
    }

    @Override
    public Paper findByAuthor(String author) {
        return papers_by_author.get(author);
    }

    @Override
    public Paper findByTag(String tag) {
        return papers_by_tag.get(tag); //or List<String> tags
    }
}
