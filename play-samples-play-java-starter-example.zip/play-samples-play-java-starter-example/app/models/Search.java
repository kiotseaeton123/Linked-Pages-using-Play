package models;

import java.util.List;

public interface Search {

    // CRUD
    // no Create, Update, or Delete commands for search engine - don't need to add, edit, or delete papers for this functionality
    List<Paper> list(); //return list of all papers
    Paper findByTitle(String title);
    Paper findByAuthor(String author);
    Paper findByTag(String tag); //or List<String> tags


}
