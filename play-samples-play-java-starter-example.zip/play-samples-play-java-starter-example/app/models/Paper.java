package models;

import java.util.List;

public class Paper {

    public final Long id;
    public final Integer year;
    public final String title;
    public final List<String> tags;
    public final List<String> author;

    public Paper(Long id, Integer year, String title, List<String> tags, List<String> author){
        this.id = id;
        this.year = year;
        this.title = title;
        this.tags = tags;
        this.author = author;
    }

}
